#include<iostream>
using namespace std;
int numOfEmployees;
struct Employee {
	string name;
	string dept;
	int salary;
};
void InputEmployeeData (Employee employees[],int numOfEmployees) {
	for (int i=0; i<numOfEmployees; i++) {
	cout<<"Employee Data: "<<endl;
	cout<<"Name: ";
	cin>>employees[i].name;
	cout<<"Dept: ";
	cin>>employees[i].dept;
	cout<<"Salary: ";
	cin>>employees[i].salary;
} 
}
void DisplayEmployeeData(Employee employees[],int numOfEmployees) {
	for (int i=0; i<numOfEmployees; i++) {
		cout<<"Employee Details: "<<endl;
		cout<<"Name: "<<employees[i].name<<endl;
		cout<<"Dept: "<<employees[i].dept<<endl;
		cout<<"Salary: "<<employees[i].salary<<endl;
	}
}
void FindHighestSalary (Employee employees[],int numOfEmployees) {
	int highsalary=0;
	for (int i=0; i<numOfEmployees; i++) {
		if (employees[i].salary>employees[highsalary].salary) {
			highsalary=i;
		}
	}
	cout<<"Employee with highest salary:"<<endl;
	cout<<"Name: "<<employees[highsalary].name<<endl;
	cout<<"Dept: "<<employees[highsalary].dept<<endl;
	cout<<"Salary: "<<employees[highsalary].salary;
}
int main () {
	
	cout<<"Enter the number of employees: ";
	cin>>numOfEmployees;
	Employee employees[numOfEmployees];
	InputEmployeeData(employees, numOfEmployees);
	DisplayEmployeeData(employees, numOfEmployees);
	FindHighestSalary(employees, numOfEmployees);
	return 0;
}