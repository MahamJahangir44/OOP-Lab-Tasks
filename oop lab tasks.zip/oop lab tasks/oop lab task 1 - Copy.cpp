#include<iostream>
using namespace std;
double kilometersToMiles () {
	double km,miles;
	cout<<"Enter the distance in km: ";
	cin>>km;
	miles=km*0.0621;
	cout<<"Distance in miles: "<<miles;
}
double celsiusToFahrenheit () {
	double celsius,fahrenheit;
	cout<<"Enter the temperature in celsius: ";
	cin>>celsius;
	fahrenheit=celsius*9/5+32;
	cout<<"Temperature in fahrenheit: "<<fahrenheit;
}
int main () {
int choice;
cout<<"1.Convert Kilometers to Miles"<<endl;
cout<<"2.Conert Celsius to Fahrenheit"<<endl;
cout<<"3.Convert Seconds into Hours, Minutes and Seconds"<<endl;
cin>>choice;
switch (choice) {
	case 1:
	kilometersToMiles ();
	break;
	case 2:
	celsiusToFahrenheit ();
	break;
	default:
	cout<<"Invalid input.";
	break;	
}
return 0;
}