#include<iostream>
using namespace std;
float basicSalary,allowance,deduction,allowper,deducper,grosssalary,netsalary;
void salaryInfo() {	
	cout<<"Enter your basic salary: ";
	cin>>basicSalary;
	cout<<"Enter your allowance %: ";
	cin>>allowper;
	cout<<"Enter your deduction %: ";
	cin>>deducper;
}
void grossSalary() {
	allowance=allowper/100*basicSalary;
	float grosssalary=basicSalary+allowance;
}
float netSalary() {
	deduction=deducper/100*basicSalary;
	float netsalary=grosssalary-deduction;
	cout<<"Net Salary: "<<netsalary;
}
int main() {
	 salaryInfo();
	grossSalary();
	netSalary();
	return 0;
}