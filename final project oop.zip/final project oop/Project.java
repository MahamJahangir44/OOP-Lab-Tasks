/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project;

/**
 *
 * @author Marium
 */
import javax.swing.*;
import java.awt.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.*;
import java.awt.event.ActionListener;

// ---------------------- Main Project (Welcome Screen) ----------------------

public class Project extends JFrame {
    JPanel welcomePanel;

    public Project() {
        setTitle("Employee Management System");
        setSize(900, 550);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);

        welcomePanel = new JPanel(new BorderLayout()) {
            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                try {
                    Image image = new ImageIcon(getClass().getResource("/background.png")).getImage();
                    g.drawImage(image, 0, 0, getWidth(), getHeight(), this);
                } catch (Exception e) {
                    System.err.println("Error loading background image: " + e.getMessage());
                    g.setColor(new Color(240, 240, 240));
                    g.fillRect(0, 0, getWidth(), getHeight());
                }
            }
        };
        welcomePanel.setOpaque(false);

        // Semi-transparent background panel
        JPanel overlayPanel = new JPanel();
        overlayPanel.setBackground(new Color(0, 0, 0, 150)); // Black with 150 alpha
        overlayPanel.setLayout(new BoxLayout(overlayPanel, BoxLayout.Y_AXIS));
        overlayPanel.setBorder(BorderFactory.createEmptyBorder(60, 50, 60, 50));
        overlayPanel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel welcomeLabel = new JLabel("Welcome to Employee Management System", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Sylfaen", Font.BOLD, 28));
        welcomeLabel.setForeground(Color.WHITE);
        welcomeLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton startButton = new JButton("Go to Login");
        startButton.setFont(new Font("SansSerif", Font.BOLD, 18));
        startButton.setBackground(new Color(0, 123, 255));
        startButton.setForeground(Color.WHITE);
        startButton.setFocusPainted(false);
        startButton.setBorder(BorderFactory.createEmptyBorder(10, 25, 10, 25));
        startButton.setAlignmentX(Component.CENTER_ALIGNMENT);

        startButton.addActionListener(e -> {
            dispose();
            new Login();
        });

        overlayPanel.add(Box.createVerticalGlue());
        overlayPanel.add(welcomeLabel);
        overlayPanel.add(Box.createRigidArea(new Dimension(0, 30)));
        overlayPanel.add(startButton);
        overlayPanel.add(Box.createVerticalGlue());

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setOpaque(false);
        centerPanel.add(overlayPanel);

        welcomePanel.add(centerPanel, BorderLayout.CENTER);
        add(welcomePanel);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Project ws = new Project();
            ws.setVisible(true);
        });
    }
}


// ---------------------- Login Module ----------------------

class Login extends JFrame implements ActionListener {
    JTextField usernameField;
    JPasswordField passwordField;
    JButton loginButton, exitButton;

    public Login() {
        setTitle("Employee Management System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(500, 300);
        setLocationRelativeTo(null);

        // Use BorderLayout for better layout control
        setLayout(new BorderLayout());

        // Title Panel
        JLabel titleLabel = new JLabel("Welcome to Login Page", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Sylfaen", Font.BOLD, 18));
        titleLabel.setForeground(Color.BLACK);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));
        add(titleLabel, BorderLayout.NORTH);

        // Form Panel
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        usernameField = new JTextField();
        passwordField = new JPasswordField();
        loginButton = new JButton("Login");
        exitButton = new JButton("Exit");

        formPanel.add(new JLabel("Username:"));
        formPanel.add(usernameField);
        formPanel.add(new JLabel("Password:"));
        formPanel.add(passwordField);
        formPanel.add(loginButton);
        formPanel.add(exitButton);

        add(formPanel, BorderLayout.CENTER);

        // Action Listeners
        loginButton.addActionListener(this);
        exitButton.addActionListener(e -> System.exit(0));

        setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String user = usernameField.getText().trim();
        String pass = new String(passwordField.getPassword()).trim();

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter the username and password", "Input Error", JOptionPane.ERROR_MESSAGE);
        } else if (user.equals("admin") && pass.equals("admin123")) {
            JOptionPane.showMessageDialog(this, "Login Successful!", "Welcome", JOptionPane.INFORMATION_MESSAGE);
            dispose();
            new Dashboard(); // Make sure this class exists
        } else {
            JOptionPane.showMessageDialog(this, "Invalid credentials!", "Login Failed", JOptionPane.ERROR_MESSAGE);
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(Login::new);
    }
}


// ---------------------- Dashboard ----------------------
class Dashboard extends JFrame {
    public Dashboard() {
        setTitle("Employee Management System");
         setSize(500, 300);
        setLayout(new BorderLayout());
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JLabel welcomeLabel = new JLabel("Welcome to Employee Management System", SwingConstants.CENTER);
        welcomeLabel.setFont(new Font("Sylfaen", Font.BOLD, 24));
        welcomeLabel.setForeground(new Color(0, 102, 204));
        welcomeLabel.setBorder(BorderFactory.createEmptyBorder(20, 10, 20, 10));
        add(welcomeLabel, BorderLayout.NORTH);

        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new GridLayout(3, 3, 10, 10));
        buttonPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 20, 20));
        buttonPanel.setBackground(new Color(240, 248, 255));

        String[] options = {
            "Manage Employees", "Department Management", "Leave Management",
            "Payroll", "Settings", "Logout"
        };

        for (String option : options) {
            JButton btn = new JButton(option);
            btn.setBackground(new Color(200, 220, 255));
            btn.setFocusPainted(false);
            btn.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    switch (option) {
                        case "Manage Employees" -> new ManageEmployee();
                        case "Payroll" -> new PayrollManagement();
                        case "Leave Management" -> new LeaveManager();
                        case "Department Management" -> new ManageDepartment();
                        case "Settings" -> new Settings();
                        case "Logout" -> {
                            dispose();
                            new Login();
                        }
                    }
                }
            });
            buttonPanel.add(btn);
        }

        add(buttonPanel, BorderLayout.CENTER);
        setVisible(true);
    }
}

// ---------------------- Manage Employee ----------------------

class ManageEmployee extends JFrame {
    private JTextField idField, nameField, positionField, salaryField, searchField;
    private JComboBox<String> departmentCombo;
    private DefaultTableModel tableModel;
    private JTable table;

    public ManageEmployee() {
        setTitle("Employee Management System");
        setSize(900, 500);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(new Color(245, 245, 245));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Input Fields
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Employee ID:"), gbc);
        idField = new JTextField(8);
        gbc.gridx = 1;
        inputPanel.add(idField, gbc);

        gbc.gridx = 2;
        inputPanel.add(new JLabel("Name:"), gbc);
        nameField = new JTextField(10);
        gbc.gridx = 3;
        inputPanel.add(nameField, gbc);

        gbc.gridx = 4;
        inputPanel.add(new JLabel("Department:"), gbc);
        departmentCombo = new JComboBox<>(new String[]{"HR", "IT", "Finance", "Sales"});
        gbc.gridx = 5;
        inputPanel.add(departmentCombo, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Position:"), gbc);
        positionField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(positionField, gbc);

        gbc.gridx = 2;
        inputPanel.add(new JLabel("Salary:"), gbc);
        salaryField = new JTextField(10);
        gbc.gridx = 3;
        inputPanel.add(salaryField, gbc);

        // Buttons
        JButton addButton = new JButton("Add");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");
        JButton searchButton = new JButton("Search");
        JButton clearButton = new JButton("Clear");

        gbc.gridx = 4;
        inputPanel.add(addButton, gbc);
        gbc.gridx = 5;
        inputPanel.add(editButton, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(deleteButton, gbc);
        gbc.gridx = 1;
        inputPanel.add(new JLabel("Search by Name:"), gbc);
        searchField = new JTextField(10);
        gbc.gridx = 2;
        inputPanel.add(searchField, gbc);
        gbc.gridx = 3;
        inputPanel.add(searchButton, gbc);
        gbc.gridx = 4;
        inputPanel.add(clearButton, gbc);

        // Table
        String[] columns = {"ID", "Name", "Department", "Position", "Salary"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Bottom Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Back to Dashboard");
        bottomPanel.add(backButton);

        // Layout
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Actions
        addButton.addActionListener(e -> addEmployee());
        editButton.addActionListener(e -> editEmployee());
        deleteButton.addActionListener(e -> deleteEmployee());
        searchButton.addActionListener(e -> searchEmployee());
        clearButton.addActionListener(e -> clearFields());
        backButton.addActionListener(e -> goToDashboard());

        setVisible(true);
    }

    private void addEmployee() {
        if (idField.getText().isEmpty() || nameField.getText().isEmpty() ||
                positionField.getText().isEmpty() || salaryField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String id = idField.getText();
        String name = nameField.getText();
        String dept = (String) departmentCombo.getSelectedItem();
        String position = positionField.getText();
        String salary = salaryField.getText();
        tableModel.addRow(new Object[]{id, name, dept, position, salary});
        clearFields();
    }

    private void editEmployee() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            tableModel.setValueAt(idField.getText(), selectedRow, 0);
            tableModel.setValueAt(nameField.getText(), selectedRow, 1);
            tableModel.setValueAt(departmentCombo.getSelectedItem(), selectedRow, 2);
            tableModel.setValueAt(positionField.getText(), selectedRow, 3);
            tableModel.setValueAt(salaryField.getText(), selectedRow, 4);
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteEmployee() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            tableModel.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void searchEmployee() {
        String searchName = searchField.getText().toLowerCase();
        table.clearSelection();
        for (int i = 0; i < tableModel.getRowCount(); i++) {
            String name = tableModel.getValueAt(i, 1).toString().toLowerCase();
            if (name.contains(searchName)) {
                table.setRowSelectionInterval(i, i);
                return;
            }
        }
        JOptionPane.showMessageDialog(this, "Employee not found!", "Error", JOptionPane.ERROR_MESSAGE);
    }

    private void clearFields() {
        idField.setText("");
        nameField.setText("");
        positionField.setText("");
        salaryField.setText("");
        searchField.setText("");
    }

    private void goToDashboard() {
        JOptionPane.showMessageDialog(this, "Returning to Dashboard...");
        dispose();
        // new Dashboard(); // Uncomment and use if you have a Dashboard class
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ManageEmployee::new);
    }
}


// ---------------------- Department Manager ----------------------
class ManageDepartment extends JFrame {
    private JTextField deptIdField, deptNameField;
    private DefaultTableModel tableModel;
    private JTable table;

    public ManageDepartment() {
        setTitle("Employee Management System - Manage Departments");
        setSize(800, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(new Color(245, 245, 245));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Input Fields
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Department ID:"), gbc);
        deptIdField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(deptIdField, gbc);

        gbc.gridx = 2;
        inputPanel.add(new JLabel("Name:"), gbc);
        deptNameField = new JTextField(15);
        gbc.gridx = 3;
        inputPanel.add(deptNameField, gbc);

        // Buttons
        JButton addButton = new JButton("Add");
        JButton editButton = new JButton("Edit");
        JButton deleteButton = new JButton("Delete");
        JButton clearButton = new JButton("Clear");

        gbc.gridx = 4;
        inputPanel.add(addButton, gbc);
        gbc.gridx = 5;
        inputPanel.add(editButton, gbc);
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(deleteButton, gbc);
        gbc.gridx = 1;
        inputPanel.add(clearButton, gbc);

        // Table
        String[] columns = {"ID", "Name"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Bottom Panel for Navigation
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Back to Dashboard");
        bottomPanel.add(backButton);

        // Layout
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Actions
        addButton.addActionListener(e -> addDepartment());
        editButton.addActionListener(e -> editDepartment());
        deleteButton.addActionListener(e -> deleteDepartment());
        clearButton.addActionListener(e -> clearFields());
        backButton.addActionListener(e -> goToDashboard());

        setVisible(true);
    }

    private void addDepartment() {
        if (deptIdField.getText().isEmpty() || deptNameField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        String id = deptIdField.getText();
        String name = deptNameField.getText();
        tableModel.addRow(new Object[]{id, name});
        clearFields();
    }

    private void editDepartment() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            tableModel.setValueAt(deptIdField.getText(), selectedRow, 0);
            tableModel.setValueAt(deptNameField.getText(), selectedRow, 1);
            clearFields();
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to edit!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteDepartment() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow >= 0) {
            tableModel.removeRow(selectedRow);
        } else {
            JOptionPane.showMessageDialog(this, "Please select a row to delete!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        deptIdField.setText("");
        deptNameField.setText("");
    }

    private void goToDashboard() {
        JOptionPane.showMessageDialog(this, "Returning to Dashboard...");
        dispose();
        // new Dashboard(); // Uncomment this line if Dashboard class exists
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(ManageDepartment::new);
    }
}


// ---------------------- leave employee ----------------------
 class LeaveManager extends JFrame {
    private JTextField empIdField, empNameField, leaveTypeField, fromDateField, toDateField, statusField;
    private DefaultTableModel tableModel;
    private JTable table;

    public LeaveManager() {
        setTitle("Leave Management System");
        setSize(1100, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JPanel inputPanel = new JPanel(new GridBagLayout());
        inputPanel.setBackground(new Color(240, 240, 240));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(5, 5, 5, 5);

        // Employee ID
        gbc.gridx = 0;
        gbc.gridy = 0;
        inputPanel.add(new JLabel("Employee ID:"), gbc);
        empIdField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(empIdField, gbc);

        // Employee Name
        gbc.gridx = 2;
        inputPanel.add(new JLabel("Employee Name:"), gbc);
        empNameField = new JTextField(15);
        gbc.gridx = 3;
        inputPanel.add(empNameField, gbc);

        // Leave Type
        gbc.gridx = 0;
        gbc.gridy = 1;
        inputPanel.add(new JLabel("Leave Type:"), gbc);
        leaveTypeField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(leaveTypeField, gbc);

        // From Date
        gbc.gridx = 2;
        inputPanel.add(new JLabel("From Date (yyyy-mm-dd):"), gbc);
        fromDateField = new JTextField(10);
        gbc.gridx = 3;
        inputPanel.add(fromDateField, gbc);

        // To Date
        gbc.gridx = 0;
        gbc.gridy = 2;
        inputPanel.add(new JLabel("To Date (yyyy-mm-dd):"), gbc);
        toDateField = new JTextField(10);
        gbc.gridx = 1;
        inputPanel.add(toDateField, gbc);

        // Status
        gbc.gridx = 2;
        inputPanel.add(new JLabel("Status (Pending/Approved/Rejected):"), gbc);
        statusField = new JTextField(10);
        gbc.gridx = 3;
        inputPanel.add(statusField, gbc);

        // Buttons
        JButton addButton = new JButton("Add Leave");
        JButton clearButton = new JButton("Clear");

        gbc.gridx = 4;
        inputPanel.add(addButton, gbc);
        gbc.gridx = 5;
        inputPanel.add(clearButton, gbc);

        // Table
        String[] columns = {"Employee ID", "Name", "Leave Type", "From", "To", "Status"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Bottom Panel for Back Button
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Back to Dashboard");
        bottomPanel.add(backButton);

        // Layout
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        // Actions
        addButton.addActionListener(e -> addLeave());
        clearButton.addActionListener(e -> clearFields());
        backButton.addActionListener(e -> goToDashboard());

        setVisible(true);
    }

    private void addLeave() {
        if (empIdField.getText().isEmpty() || empNameField.getText().isEmpty() || leaveTypeField.getText().isEmpty()
                || fromDateField.getText().isEmpty() || toDateField.getText().isEmpty() || statusField.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String empId = empIdField.getText();
        String name = empNameField.getText();
        String leaveType = leaveTypeField.getText();
        String from = fromDateField.getText();
        String to = toDateField.getText();
        String status = statusField.getText();

        tableModel.addRow(new Object[]{empId, name, leaveType, from, to, status});
        clearFields();
    }

    private void clearFields() {
        empIdField.setText("");
        empNameField.setText("");
        leaveTypeField.setText("");
        fromDateField.setText("");
        toDateField.setText("");
        statusField.setText("");
    }

    private void goToDashboard() {
        JOptionPane.showMessageDialog(this, "Returning to Dashboard...");
        dispose();
        // new Dashboard(); // Uncomment if you have a Dashboard class
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(LeaveManager::new);
    }
}

// ---------------------- payroll ----------------------

 class PayrollManagement extends JFrame {
    private JTextField empIdField, empNameField, basicSalaryField, bonusField, deductionsField;
    private DefaultTableModel tableModel;
    private JTable table;

    public PayrollManagement() {
        setTitle("Payroll Management");
        setSize(800, 600);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Input Panel
        JPanel inputPanel = new JPanel(new GridLayout(3, 4, 5, 5));

        inputPanel.add(new JLabel("Employee ID:"));
        empIdField = new JTextField();
        inputPanel.add(empIdField);

        inputPanel.add(new JLabel("Employee Name:"));
        empNameField = new JTextField();
        inputPanel.add(empNameField);

        inputPanel.add(new JLabel("Basic Salary:"));
        basicSalaryField = new JTextField();
        inputPanel.add(basicSalaryField);

        inputPanel.add(new JLabel("Bonus:"));
        bonusField = new JTextField();
        inputPanel.add(bonusField);

        inputPanel.add(new JLabel("Deductions:"));
        deductionsField = new JTextField();
        inputPanel.add(deductionsField);

        JButton addButton = new JButton("Add/Update Payroll");
        JButton clearButton = new JButton("Clear");
        inputPanel.add(addButton);
        inputPanel.add(clearButton);

        // Table
        String[] columns = {"Employee ID", "Name", "Basic Salary", "Bonus", "Deductions", "Net Salary"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane tableScroll = new JScrollPane(table);

        // Bottom Button Panel
        JPanel bottomPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton backButton = new JButton("Back to Dashboard");
        bottomPanel.add(backButton);

        // Button Actions
        addButton.addActionListener(e -> addPayroll());
        clearButton.addActionListener(e -> clearFields());
        backButton.addActionListener(e -> goToDashboard());

        // Layout
        setLayout(new BorderLayout());
        add(inputPanel, BorderLayout.NORTH);
        add(tableScroll, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void addPayroll() {
        try {
            if (empIdField.getText().isEmpty() || empNameField.getText().isEmpty() ||
                    basicSalaryField.getText().isEmpty() || bonusField.getText().isEmpty() || deductionsField.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please fill in all fields!", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            String empId = empIdField.getText().trim();
            String empName = empNameField.getText().trim();
            double basicSalary = Double.parseDouble(basicSalaryField.getText().trim());
            double bonus = Double.parseDouble(bonusField.getText().trim());
            double deductions = Double.parseDouble(deductionsField.getText().trim());
            double netSalary = basicSalary + bonus - deductions;

            boolean found = false;
            for (int i = 0; i < tableModel.getRowCount(); i++) {
                if (tableModel.getValueAt(i, 0).equals(empId)) {
                    tableModel.setValueAt(empName, i, 1);
                    tableModel.setValueAt(basicSalary, i, 2);
                    tableModel.setValueAt(bonus, i, 3);
                    tableModel.setValueAt(deductions, i, 4);
                    tableModel.setValueAt(netSalary, i, 5);
                    found = true;
                    break;
                }
            }

            if (!found) {
                tableModel.addRow(new Object[]{empId, empName, basicSalary, bonus, deductions, netSalary});
            }

            clearFields();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for salary, bonus, and deductions!", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void clearFields() {
        empIdField.setText("");
        empNameField.setText("");
        basicSalaryField.setText("");
        bonusField.setText("");
        deductionsField.setText("");
    }

    private void goToDashboard() {
        // Placeholder for dashboard navigation
        JOptionPane.showMessageDialog(this, "Returning to Dashboard...");
        dispose(); // Close current window
        // new Dashboard(); // Uncomment this if Dashboard class exists
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(PayrollManagement::new);
    }
}

// ---------------------- Settings ----------------------
class Settings extends JFrame {
    public Settings() {
        setTitle("Settings");
        setSize(500, 300);
        setLocationRelativeTo(null);
        setLayout(new GridLayout(0, 1));

        JButton manageUsers = new JButton("Manage Users");
        JButton backup = new JButton("Backup Data");

        add(manageUsers);
        add(backup);

        manageUsers.addActionListener(e -> JOptionPane.showMessageDialog(this, "User Management Placeholder"));
        backup.addActionListener(e -> JOptionPane.showMessageDialog(this, "Backup Completed"));

        setVisible(true);
    }
}
